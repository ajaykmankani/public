<?php
$website = "stock-market";
include($website.'/variables/plans.php');
include($website.'/variables/site_setting.php');