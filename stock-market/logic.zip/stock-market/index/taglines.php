<div class="container space">
    <div class="row">
        <div class="col-md-3">
            <h5 class="text-blue fs-6 fs-bold"><i class="bi bi-check2-circle fs-bolder text-blue fs-4"></i> SEBI Registered</h5>
        </div>
        <div class="col-md-3">
            <h5 class="text-blue fs-6 fs-bold"><i class="bi bi-check2-circle fs-bolder text-blue fs-4"></i> 20+ Years Experience</h5>
        </div>
        <div class="col-md-3">
            <h5 class="text-blue fs-6 fs-bold"><i class="bi bi-check2-circle fs-bolder text-blue fs-4"></i> 115000+ Happy Investors</h5>
        </div>
        <div class="col-md-3">
            <h5 class="text-blue fs-6 fs-bold"><i class="bi bi-check2-circle fs-bolder text-blue fs-4"></i> 24x7 Support</h5>
        </div>
    </div>
</div>