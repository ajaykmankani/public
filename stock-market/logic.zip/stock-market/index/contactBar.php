<div class="sec-info space" style=" background-image: url(stock-market/images/bg-2.webp);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center; height: 320px;
    width: 100%;">
    <div class="container">
        <div class="row d-flex align-items-center justify-content-center slide-up">
            <div class="col-md-9">

                <h3 class="text-white mt-2 fs-bold">Daily <span class="text-white px-2 animated-text"> Highly Accurate
                        Intraday Call</span> in all Segment.</h3>
                <p class="text-white">If you are looking for most accurate free intraday trading tips provider company
                    in India then Stock Benifits will help you to earn maximum profit with minimum risk.</p>
            </div>
            <div class="col-md-3 mt-2">
                <button type="btn" onclick="showForm()" class="fs-6 bg-blue px-4 py-2 border-0 rounded text-white">Get
                    Free Trial</button>

            </div>
        </div>
    </div>
</div>