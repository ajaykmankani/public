<div class="section-earning space" style=" background-image: url(stock-market/images/bg-3.webp);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;" height="500px" width="1900px">
<div class="container">
    <div class="row">
        <div class="col-md-12 d-flex align-items-center justify-content-center flex-column text-center">
            <h2 class="text-white fs-1 fw-bolder" style="line-height: 1.6em;">Increase your profit with our<br><span class="bg-light-blue text-white p-2"> high-quality</span> Nifty Option Tips, Bank <br>Nifty Options Tips, Nifty Tips and <br>Bank Nifty Tips</h2>

            <p class="text-white fs-5">Start Recovering Your Previous Loss Now</p>
            
            <button type="btn" onclick="showForm()" class="fs-6 bg-blue px-4 py-2 border-0 rounded text-white">START EARNING</button>
          
        </div>
    </div>
</div>
</div>