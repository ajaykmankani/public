<div class="shape-divider shape-divider-bottom d-hide-mob grey-shape-d" style="height: 102px;">
	<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1920 102" preserveAspectRatio="xMinYMin">
		<path fill="#F9F9F9" d="M1895,78c-56.71-6.03-113.75-12.1-167-17c-75.42-6.94-133.81-10.66-171-13c-62.1-3.91-108.85-5.97-155-8
								c-35.96-1.58-78.06-3.42-133-5c-59.81-1.72-103.18-2.23-172-3c-92.17-1.03-154.41-1.01-169-1c-69.05,0.05-115.16,0.67-137,1
								c-43.08,0.65-76.21,1.48-97,2c-28.02,0.7-71.13,1.8-128,4c-16.64,0.64-57.72,2.28-111,5c-26.12,1.33-67.11,3.45-121,7
								c-21.14,1.39-54.21,3.59-96,7c-19.93,1.63-39.22,3.32-47,4c-16.12,1.41-33.55,2.94-55,5c-26.48,2.54-19.07,2.04-77,8
								c-19.39,1.99-36.94,3.77-60.59,7.46V103H1923V81C1916.55,80.3,1906.82,79.26,1895,78z"></path>
	</svg>
</div>
<div class="performance-section space bg-light" id="performance">
	<div class="container">
		<div class="row">
			<div class="col-md-7 slide-left">
				<span class="light-text">RECENT WORK</span>
				<h3 class="text-blue fw-bolder fs-2"> Our Past Performance</h3>
			</div>
			<div class="col-md-5 slide-right">
				<button type="btn" onclick="showForm()" class="fs-6 bg-blue px-4 py-2 border-0 rounded text-white">REQUEST CALL BACK</button>
				<a href="tel:<?= $phone ?>"><button type="btn" class="fs-6 bg-light-blue px-4 py-2 border-0 rounded text-white">GET FREE TRIAL</button></a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<p>We are one of the leading Advisory for Indian stock market. We give guidance on movements, valuations
					and recommendations based on best Technical and fundamental analysis. We sincerely hope that each
					and every trader doing trading with us may get good profit whatever he/she is looking for.</p>
			</div>

		</div>
		<div class="row mt-4">
			<div style="max-width: 100%; overflow-x: auto;">
				<table class="table table-striped table-hover" style="font-size: 12px; white-space: nowrap;">
					<thead>
						<tr>
							<th>DATE</th>
							<th>TRADE GIVEN</th>
							<th>AT</th>
							<th>AVERAGE AT</th>
							<th>STOP LOSS</th>
							<th>TAREGET</th>
							<th>ACHIEVED</th>
						</tr>
					</thead>
					<tbody>

						<tr>
							<td>06-0CT 2022</td>
							<td>BUY OCT NIFTY 17300 CE&nbsp;</td>
							<td>140-150</td>
							<td>100</td>
							<td>70</td>
							<td>230/300</td>
							<td>low&nbsp;160&nbsp;from buying level thereafter high&nbsp;177&nbsp;(recommended
								to book at&nbsp;177)</td>
						</tr>
						<tr>
							<td>06-Oct-22</td>
							<td>BUY 06 0CT NIFTY 17300 CE</td>
							<td>65-75</td>
							<td>35-40</td>
							<td>25</td>
							<td>125/150</td>
							<td>low&nbsp;66.75&nbsp;from buying level,recommended to book at&nbsp;86</td>
						</tr>
						<tr>
							<td>07-Oct-22</td>
							<td>BUY 13 OCT BANK NIFTY 38900 PE</td>
							<td>380-400</td>
							<td>300</td>
							<td>200</td>
							<td>600/750</td>
							<td>trade executed,recommended to book at&nbsp;437</td>
						</tr>
						<tr>
							<td>11-Oct-22</td>
							<td>BUY 13 OCT BANK NITY 38900 CE</td>
							<td>370</td>
							<td>240</td>
							<td>200</td>
							<td>500</td>
							<td>exit at cost</td>
						</tr>
						<tr>
							<td>12-Oct-22</td>
							<td>BUY 20 OCT NIFTY 16900</td>
							<td>250-260</td>
							<td>200</td>
							<td>170</td>
							<td>350/450</td>
							<td>low240 from buying level thereafter high&nbsp;335,recommended to book
								at&nbsp;313</td>
						</tr>
						<tr>
							<td>13-Oct-22</td>
							<td>BUY 20 OCT NIFTY 16800 CE</td>
							<td>250-260</td>
							<td>200</td>
							<td>170</td>
							<td>350-450</td>
							<td>low&nbsp;278&nbsp;from buying level,recommended to buy at&nbsp;278, recommended
								to book at&nbsp;340</td>
						</tr>
						<tr>
							<td>14-Oct-22</td>
							<td>BUY 20 OCT BANK NIFTY 39500 CE</td>
							<td>350-360</td>
							<td>260</td>
							<td>160</td>
							<td>560/650</td>
							<td>low&nbsp;364&nbsp;from buying level recommended to book at&nbsp;412&nbsp;</td>
						</tr>
						<tr>
							<td>19-Oct-22</td>
							<td>BUY 27 OCT NIFTY 17400 CE</td>
							<td>220-230</td>
							<td>180</td>
							<td>150</td>
							<td>310/360</td>
							<td>low&nbsp;216&nbsp;buying was 220-230 recommended to book at&nbsp;245</td>
						</tr>
						<tr>
							<td>25-Oct-22</td>
							<td>BUY 27 OCT BANK NIFTY 41000 CE&nbsp;</td>
							<td>350-360</td>
							<td>260</td>
							<td>160</td>
							<td>560/650</td>
							<td>high&nbsp;433&nbsp;from buying rice,&nbsp;recommended to book at&nbsp;420</td>
						</tr>
						<tr>
							<td>31-Oct-22</td>
							<td>BUY 03 NOV NIFTY 17800 CE&nbsp;</td>
							<td>180-190</td>
							<td>150</td>
							<td>120</td>
							<td>260/310</td>
							<td>low&nbsp;200&nbsp;recommended to buy at&nbsp;200,recommended to book at&nbsp;245
							</td>
						</tr>
						<tr>
							<td>01-Sep</td>
							<td>BUY 08 SEP NIFTY 17500 CE&nbsp;</td>
							<td>200-210</td>
							<td>150</td>
							<td>120</td>
							<td>300/375</td>
							<td>trade executed from buying level recommended to book at 236</td>
						</tr>
						<tr>
							<td>06-Sep</td>
							<td>BUY 08 SEP BANK NIFTY 39600 CE&nbsp;</td>
							<td>340-350</td>
							<td>250</td>
							<td>150</td>
							<td>550/650</td>
							<td>trade executed from buying level,recommended to book at 377</td>
						</tr>
						<tr>
							<td>07-Sep</td>
							<td>BUY 08 SEP BANK NIFTY 39300 CE&nbsp;</td>
							<td>300-320</td>
							<td>220</td>
							<td>150</td>
							<td>490/600</td>
							<td>trade executed from buying level,recommended to book at 421</td>
						</tr>
						<tr>
							<td>08-Sep</td>
							<td>BUY 08 SEP BANK NIFTY 40300 PE</td>
							<td>210-230</td>
							<td>130</td>
							<td>100</td>
							<td>360/500</td>
							<td>trade executed from buying level,high 381(updated) first target done</td>
						</tr>
						<tr>
							<td>09-Sep</td>
							<td>BUY 15 SEP NIFTY 17700 CE&nbsp;</td>
							<td>210-220</td>
							<td>170</td>
							<td>140</td>
							<td>300/340</td>
							<td>trade executed from buying level,recommended to book at 248</td>
						</tr>
						<tr>
							<td>13-Sep</td>
							<td>BUY 15 SEP BANK NIFTY 40800 CE</td>
							<td>280-290</td>
							<td>210</td>
							<td>170</td>
							<td>410/500</td>
							<td>trade executed from buying level,recommended to book at 340</td>
						</tr>
						<tr>
							<td>19-Sep</td>
							<td>BUY 22 SEP BANK NIFTY 40800 CE</td>
							<td>390-400</td>
							<td>300</td>
							<td>200</td>
							<td>600/750</td>
							<td>trade executed from buying level,recommended to book at 529</td>
						</tr>
						<tr>
							<td>21-Sep</td>
							<td>BUY 29 SEP NIFTY 17700 CE</td>
							<td>215-230</td>
							<td>170</td>
							<td>140</td>
							<td>320/400</td>
							<td>Low 212 from buiyng level thereafter high 261 recommended to book at 241</td>
						</tr>
						<tr>
							<td>22-Sep</td>
							<td>BUY 29 SEP NIFTY 17500 CE</td>
							<td>230-240</td>
							<td>180</td>
							<td>150</td>
							<td>330-420</td>
							<td>trade executed from buying level thereafter,hits first target 91 points gain
							</td>
						</tr>
						<tr>
							<td>23-Sep</td>
							<td>BUY 29 SEP NIFTY 17300 CE</td>
							<td>250-260</td>
							<td>190</td>
							<td>170</td>
							<td>350/440</td>
							<td>trade executed from buying level thereafter recommended to book at279</td>
						</tr>
						<tr>
							<td>27-Sep</td>
							<td>BUY 06 OCT NIFTY 16900 CE&nbsp;</td>
							<td>290-300</td>
							<td>240</td>
							<td>180</td>
							<td>420/500</td>
							<td>trade executed from buying level thereafter high 383 recommended to book at 370
							</td>
						</tr>
						<tr>
							<td>28-Sep</td>
							<td>BUY 06 OCT NIFTY 16900 CE&nbsp;</td>
							<td>250-260</td>
							<td>200</td>
							<td>180</td>
							<td>340/400</td>
							<td>trade executed from buying level thereafter recommended to book at 280</td>
						</tr>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>