<?php

// $plan1 = array(
//         array(
//         'title'=>'Wifi Seamless',
//         'sub_title' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit..',
//         'color'=>'#303539',
//         'link' => '',

//         ),
//         array(
//         'title'=>'Speed On Demand',
//         'sub_title' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit..',
//         'color'=>'#ffffff',
//         'link' => '',
//         ),
//         array(
//          'title'=>'Upgrade Speed',
//          'sub_title' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit..',
//          'color'=>'#ffffff',
//          'link' => '',
//         ),
//         array(
//          'title'=>'Upgrade Speed',
//          'sub_title' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit..',
//          'color'=>'#ffffff',
//          'link' => '',
//             ),
//             array(
//              'title'=>'Upgrade Speed',
//              'sub_title' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit..',
//              'color'=>'#ffffff',
//              'link' => '',
//                 )
//         );


//======================================================================================//


        $packages = array(

            array(
                
                'title' => 'Index F&Os',
                
                'list' => array(

                  
                    "Pre-Market View & Trading Levels & Strategy",	
                    " Get 1-2 Trades Daily (Positional + Intraday)",				
                    "Regular Follow Up & Updates",											
                     "Get Live Market Guidance & Risk-Management",																
                     "Potential Profit Target 15k Per Trade",										
                     "Objective to capture Index Swings",											
                     " Accuracy 90% & Above",
                     
                ),
                'link' => 'GET FREE DEMO'
                
            ),
            array(
               
                'title' => 'Stock F&Os',
                
                
                'list' => array(

                    "Get 2-3 Trades Daily (Positional + Intraday)",																
                    "Proper Entry & Exit Level.",															
                    "Regular Follow Up & Updates	",															
                    "Guidance via Option Risk Management",																
                    "Proper Technical View, Logic & Levels for Positional Trades	",																
                    "Objective to capture market momentum UP Or Down",															
                    "Accuracy 90% & Above",	
                     
                ),
                'link' => 'GET FREE DEMO'
                
            ),
            array(
                
                'title' => 'Premium Combo Package',
                
                
                'list' => array(

                    "Best Filtered trade In Index OR Stock Trades"	,															
                    "Get 2-3 Positional Trades"	,															
                    "Get 3-4 Intraday Index/ Stock trades"						,										
                    "Index/ Stock Option Trade"	,															
                    "Customize Package as per Client Requirement	"				,												
                    "Objective wealth creation" 	,															
                    "Accuracy 90% and above	",
                     
                     
                ),
                'link' => 'GET FREE DEMO'
                
            ),
            array(
                
                'title' => 'AGS Super Package',
                
                'list' => array(

                    "Personalized Service by our Head Research Analyst",																
                "Discuss & plan strategy for maximum profitable bets	",																
                
                "Special Focus on client positions		",														
                "Personal guidance during market hours",																
                "Best Option Strategies & Hedging",																	
                "Minimum Risk & Maximum Return Positional Strategies	",
              "  PAIR TRADING",																
              "  Objective utmost satisfaction & Wealth Creation	",	 
                     
                ),
                'link' => 'GET FREE DEMO'
                
            ),
        );



?>