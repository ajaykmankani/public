<div id="background">
    <div id="popup" class="pop-new form-popup">

        <div class="container-fluid">

            <div class="row">

                <div class="col-md-6 col-xs-12 hide-in-mob half-left">
                <div class="header-from slide-up px-4 py-5 shadow-lg rounded bg-white">
              <form method="POST" action="contactthanks.php" id="form1" name="form1"onSubmit="return checkform(this);">
                    <div class="col-12">
                        <h4 class="fw-800">Request a Callback</h4>
                        <p>Enter your details in the form and we will call you back.</p>
                    </div>

               <div class="col-12 mt-4">

                    <div class="form-input mt-2 ">
                    <input type="text" required name="name" placeholder="Name">

                     </div>
                    </div>
                <div class="col-12 mt-4">

                    <div class="form-input mt-2 ">
                     <input type="text" required name="phone" placeholder="Phone">

                     </div>

                 </div>
                                
                <div class="col-12 mt-4">

                    <div class="form-input mt-2">
                      <select required name="boarding">
                          <option selected>Select Service</option>
                          <option value="NIFTY / Bank NIFTY">NIFTY / Bank NIFTY</option>
                          <option value="Equity Cash / Intraday">Equity Cash / Intraday</option>
                          <option value="Option (Call - Put)">Option (Call - Put)</option>
                          <option value="Future (Derivatives)">Future (Derivatives)</option>
                          <option value="index">index</option>
                          
                      </select>

                    </div>

                </div>
                <div class="col-12 mt-4">

                     <button class="btn2 mt-4 rounded" id="frm_submit_btn2" type="btn btn-primary submit" name="btnsubmit">Call Me Back
                     </button>

                </div>
              </form>
             </div>
                </div>




                            <div class="col-md-6 col-xs-12  half-right">

            <img src="stock-market/images/popup.jpg" alt="">
                            </div>

            </div>


        </div>
    </div>


</div>


<script  type="text/javascript">
function showForm() {
    var form = document.getElementById("popup");
    form.style.display = "block";
    document.body.style.overflow = "hidden";
    document.querySelector("#background").style.display = "block";
}


document.querySelector("#close").addEventListener("click", function() {
    document.querySelector("#popup").style.display = "none";
    document.querySelector("#background").style.display = "none"; // hide the background element
    document.body.style.overflow = "auto";
});





document.querySelector("#background").addEventListener("click", function(event) {
    if (event.target === this) {
        console.log('clicked')

        document.querySelector("#popup").style.display = "none";
        document.querySelector("#background").style.display = "none";
        document.body.style.overflow = "auto";
    }
});
</script>