<?php include('containers/header.php'); ?>



<!-- Top Header -->
<?php include('containers/navbar.php'); ?>

<section class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="thanks-content">
                    <h3>Thank you for Registering With Stock Benifits.</h3>

                    <p>We Have Received Your Request.</p>
                    <p>Our Executive Will Call You Back Shortly.</p>
                    <p>For Urgent Query, You Are Free To Call On <a href="tel:+91-7400041121"> +91-7400041121</a>
                        Anytime.</p>

                    <p class="top">Thank You,</p>
                    <p>Stock Benifits</p>
                </div>
            </div>
            <div class="col-md-6 m-md-auto">
                <img src="img/thank-you.webp" width="100%">
            </div>
        </div>
    </div>
</section>

<style>
footer#footer {
    position: inherit !important;
}
</style>
<?php include('containers/footer.php'); ?>

<script src="../js/jquery.min.js"></script>
<script src="../js/jquery-migrate-3.0.1.min.js"></script>

</body>

</html>