<?php include('global-variables.php') ?>



<?php foreach($privacy_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
